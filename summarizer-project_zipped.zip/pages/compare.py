import streamlit as st
from transformers import pipeline
from rouge_score import rouge_scorer
import plotly.express as px
import textstat

# Load models only once
@st.cache_resource
def load_models():
    summarizer = pipeline("summarization", model="facebook/bart-large-cnn")
    paraphraser = pipeline("text2text-generation", model="Vamsi/T5_Paraphrase_Paws")
    return summarizer, paraphraser

summarizer, paraphraser = load_models()

st.title("Summarizer & Paraphraser Engine")

uploaded_file = st.file_uploader("Upload a text file", type=["txt"])
if uploaded_file:
    text = uploaded_file.read().decode("utf-8")

    st.subheader("Original Text")
    st.write(text)

    col1, col2 = st.columns(2)

    # --- Summarizer Section ---
    with col1:
        st.markdown("### Summarization")
        length_option = st.selectbox("Choose Summary Length", ["Short", "Medium", "Long"])

        if length_option == "Short":
            max_len, min_len = 50, 15
        elif length_option == "Medium":
            max_len, min_len = 100, 40
        else:  # Long
            max_len, min_len = 150, 60

        summary = summarizer(text, max_length=max_len, min_length=min_len, do_sample=False)[0]["summary_text"]

        st.markdown("**Generated Summary:**")
        st.info(summary)

        # Readability
        st.markdown("**Readability Scores (Summary):**")
        st.json({
            "Flesch Reading Ease": textstat.flesch_reading_ease(summary),
            "Gunning Fog": textstat.gunning_fog(summary),
            "SMOG Index": textstat.smog_index(summary)
        })

    # --- Paraphraser Section ---
    with col2:
        st.markdown("### Paraphrasing")
        level_option = st.selectbox("Choose Level", ["Beginner", "Intermediate", "Advanced"])

        if level_option == "Beginner":
            temp = 0.7
        elif level_option == "Intermediate":
            temp = 1.0
        else:  # Advanced
            temp = 1.5

        paraphrase = paraphraser(
            "paraphrase: " + text,
            max_length=150,
            num_return_sequences=1,
            temperature=temp
        )[0]["generated_text"]

        st.markdown("**Generated Paraphrase:**")
        st.success(paraphrase)

        # Readability
        st.markdown("**Readability Scores (Paraphrase):**")
        st.json({
            "Flesch Reading Ease": textstat.flesch_reading_ease(paraphrase),
            "Gunning Fog": textstat.gunning_fog(paraphrase),
            "SMOG Index": textstat.smog_index(paraphrase)
        })

    # --- ROUGE Comparison ---
    st.subheader("ROUGE Evaluation")

    scorer = rouge_scorer.RougeScorer(["rouge1", "rouge2", "rougeL"], use_stemmer=True)
    summary_scores = scorer.score(text, summary)
    paraphrase_scores = scorer.score(text, paraphrase)

    summary_data = {
        "ROUGE-1": summary_scores["rouge1"].fmeasure,
        "ROUGE-2": summary_scores["rouge2"].fmeasure,
        "ROUGE-L": summary_scores["rougeL"].fmeasure,
    }
    paraphrase_data = {
        "ROUGE-1": paraphrase_scores["rouge1"].fmeasure,
        "ROUGE-2": paraphrase_scores["rouge2"].fmeasure,
        "ROUGE-L": paraphrase_scores["rougeL"].fmeasure,
    }

    fig = px.bar(
        x=list(summary_data.keys()) * 2,
        y=list(summary_data.values()) + list(paraphrase_data.values()),
        color=["Summary"] * 3 + ["Paraphrase"] * 3,
        barmode="group",
        labels={"x": "ROUGE Metric", "y": "ROUGE Score"},
        title="ROUGE Score Comparison"
    )
    st.plotly_chart(fig, use_container_width=True)
