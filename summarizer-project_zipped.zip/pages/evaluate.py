import streamlit as st
from models import get_summarizer
import fitz  # PyMuPDF for PDFs

# -----------------------------
# Helper: extract text from PDF
# -----------------------------
def extract_text_from_pdf(uploaded_file):
    text = ""
    with fitz.open(stream=uploaded_file.read(), filetype="pdf") as doc:
        for page in doc:
            text += page.get_text()
    return text


# -----------------------------
# Summarizer Page
# -----------------------------
def summarizer_page():
    # Check if logged in
    if "logged_in" not in st.session_state or not st.session_state.logged_in:
        st.warning("⚠️ Please log in first.")
        st.switch_page("pages/login.py")

    st.title("📄 Text Summarizer")

    summarizer = get_summarizer()

    option = st.radio("Choose Input Method:", ["✍️ Enter Text", "📂 Upload File"])

    text = ""

    if option == "✍️ Enter Text":
        text = st.text_area("Enter text to summarize:", height=200)

    elif option == "📂 Upload File":
        uploaded_file = st.file_uploader("Upload a TXT or PDF file", type=["txt", "pdf"])
        if uploaded_file is not None:
            try:
                if uploaded_file.type == "text/plain":
                    text = uploaded_file.read().decode("utf-8")
                elif uploaded_file.type == "application/pdf":
                    text = extract_text_from_pdf(uploaded_file)
                else:
                    st.error("❌ Unsupported file format.")

                # Show extracted text for user confirmation
                st.text_area("📑 Extracted Text:", value=text[:2000], height=200)
            except Exception as e:
                st.error(f"⚠️ Error reading file: {e}")

    if st.button("Summarize"):
        if text.strip() == "":
            st.warning("⚠️ Please provide some text.")
        else:
            with st.spinner("Summarizing..."):
                try:
                    summary = summarizer(text, max_length=130, min_length=30, do_sample=False)
                    st.subheader("✅ Summary")
                    st.write(summary[0]['summary_text'])
                except Exception as e:
                    st.error(f"⚠️ Error during summarization: {e}")

    if st.button("Logout"):
        st.session_state.logged_in = False
        st.session_state.username = ""
        st.switch_page("app.py")  # back to main page


# -----------------------------
# Run page directly
# -----------------------------
if __name__ == "__main__":
    summarizer_page()
