import streamlit as st
from transformers import pipeline

# -----------------------------
# Load Paraphrasing Model
# -----------------------------
@st.cache_resource
def load_paraphraser():
    return pipeline(
        "text2text-generation",
        model="Vamsi/T5_Paraphrase_Paws",
        tokenizer="Vamsi/T5_Paraphrase_Paws",
        use_fast=False   # 👈 Important fix to avoid tokenizer conversion error
    )

paraphraser = load_paraphraser()

# -----------------------------
# Main Function
# -----------------------------
def main():
    st.title("📝 Paraphrasing Tool")

    uploaded_file = st.file_uploader("📂 Upload a text file", type=["txt"])

    if uploaded_file:
        # Read file
        text = uploaded_file.read().decode("utf-8")

        st.subheader("📄 Original Text")
        st.write(text)

        if st.button("🔄 Paraphrase"):
            with st.spinner("Paraphrasing in progress..."):
                # Run paraphraser
                paraphrased = paraphraser(
                    text,
                    max_length=256,
                    num_return_sequences=1,
                    do_sample=True
                )
                result = paraphrased[0]["generated_text"]

                st.subheader("✨ Paraphrased Text")
                st.write(result)

                # Download button
                st.download_button(
                    label="💾 Download Paraphrased Text",
                    data=result,
                    file_name="paraphrased_output.txt",
                    mime="text/plain"
                )

if __name__ == "__main__":
    main()
