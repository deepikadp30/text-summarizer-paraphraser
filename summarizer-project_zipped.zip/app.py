import streamlit as st

# -----------------------------
# Main Landing Page
# -----------------------------
st.set_page_config(page_title="Text Summarizer & Paraphraser", page_icon="📘")

st.title("📘 Text Summarizer & Paraphraser")
st.write("""
Welcome to the **Text Summarizer and Paraphraser Application** 🎉  

This tool helps you:
- 📄 Summarize large text into short key points  
- ✍️ Paraphrase text for better readability  
- 🔐 Secure access with Login & Signup  

Please choose an option below to continue:
""")

col1, col2 = st.columns(2)

with col1:
    st.page_link("pages/login.py", label="🔒 Login", icon="➡️")

with col2:
    st.page_link("pages/signup.py", label="📝 Signup", icon="➡️")
  